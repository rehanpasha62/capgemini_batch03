// All backend calls for the User entity live here
const API = 'http://localhost:8080';

const check = async (res) => {
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Server returned ${res.status}. ${text.slice(0, 150)}`);
  }
  return res;
};

// READ   -> GET /getuser
export const getUsers = async () => {
  const res = await check(await fetch(`${API}/getuser`));
  return res.json();
};

// CREATE -> POST /saveuser
export const addUser = async (user) =>
  check(await fetch(`${API}/saveuser`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(user),
  }));

// UPDATE -> PUT /updateuser/{id}
export const updateUser = async (id, user) =>
  check(await fetch(`${API}/updateuser/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(user),
  }));

// DELETE -> DELETE /deleteuser/{id}
export const deleteUser = async (id) =>
  check(await fetch(`${API}/deleteuser/${id}`, { method: 'DELETE' }));
