import React from 'react';
import { deleteUser } from '../api';

const UserList = ({ users, fetchUsers, setEditingUser, setError }) => {
  const handleDelete = async (id) => {
    try {
      await deleteUser(id);
      await fetchUsers();
    } catch (err) {
      setError('Delete failed: ' + err.message);
    }
  };

  return (
    <div className="user-list">
      {users.length === 0 ? (
        <p>No users yet. Add one using the form above.</p>
      ) : (
        <table>
          <thead>
            <tr><th>ID</th><th>Name</th><th>Email</th><th>Designation</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.designation}</td>
                <td>
                  <button className="edit-btn" onClick={() => setEditingUser(user)}>Edit</button>
                  <button className="delete-btn" onClick={() => handleDelete(user.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default UserList;
