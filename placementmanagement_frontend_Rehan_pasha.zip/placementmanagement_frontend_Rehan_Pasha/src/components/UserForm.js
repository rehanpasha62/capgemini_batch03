import React, { useState, useEffect } from 'react';
import { addUser, updateUser } from '../api';

const UserForm = ({ fetchUsers, editingUser, setEditingUser, setError }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [designation, setDesignation] = useState('');

  // Edit clicked -> fill the form with that user's data
  useEffect(() => {
    if (editingUser) {
      setName(editingUser.name);
      setEmail(editingUser.email);
      setDesignation(editingUser.designation);
    }
  }, [editingUser]);

  const resetForm = () => {
    setEditingUser(null);
    setName('');
    setEmail('');
    setDesignation('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const user = { name, email, designation };
    try {
      if (editingUser) {
        await updateUser(editingUser.id, user);
      } else {
        await addUser(user);
      }
      await fetchUsers();
      resetForm();
    } catch (err) {
      setError('Save failed: ' + err.message);
    }
  };

  return (
    <div className="form-container">
      <h2>{editingUser ? 'Edit User' : 'Add User'}</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" required />
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
        <input type="text" value={designation} onChange={(e) => setDesignation(e.target.value)} placeholder="Designation" required />
        <div>
          <button type="submit">{editingUser ? 'Update User' : 'Add User'}</button>
          {editingUser && (
            <button type="button" className="cancel-btn" onClick={resetForm}>Cancel</button>
          )}
        </div>
      </form>
    </div>
  );
};

export default UserForm;
