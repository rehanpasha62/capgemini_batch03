import React, { useState, useEffect } from 'react';
import './App.css';
import UserForm from './components/UserForm';
import UserList from './components/UserList';
import { getUsers } from './api';

const App = () => {
  const [users, setUsers] = useState([]);
  const [editingUser, setEditingUser] = useState(null);
  const [error, setError] = useState('');

  const fetchUsers = async () => {
    try {
      setUsers(await getUsers());
      setError('');
    } catch (err) {
      setError(
        'Cannot reach the backend (' + err.message +
        '). Check that Spring Boot is running on port 8080 and CorsConfig is added.'
      );
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="App">
      <h1>Placement Management - Users</h1>
      {error && <div className="error-box">{error}</div>}
      <UserForm
        fetchUsers={fetchUsers}
        editingUser={editingUser}
        setEditingUser={setEditingUser}
        setError={setError}
      />
      <UserList
        users={users}
        fetchUsers={fetchUsers}
        setEditingUser={setEditingUser}
        setError={setError}
      />
    </div>
  );
};

export default App;
